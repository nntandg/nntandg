---
title:  About me
date: 2019-03-21 20:38:49
type: "about"

comments: false
---

# 个人简介
毕业于郑州大学软件工程专业，毕业后在从事java方向工作。两年的工作经验使我熟悉javaWEB开发的企业架构，能够独立负责开发整个服务端。
熟悉企业级常用的技术：spring、springMVC、springBoot、redis、mysql、sqlserver、nginx等。
熟悉使用企业级常用的工具：YAPI、SonarQube、Jenkins等。

比较喜欢将工作中碰到的问题和自己学习的心得笔记记录下来，方便自己以后查看。同时也方便和广大同胞进行交流互动。

个人座右铭：别让生活成为梦想的羁绊。

个人公众号：程序员爱酸奶
分享各种学习资料，包含java，linux，大数据等。资料包含视频文档以及源码，同时分享本人及投递的优质技术博文。

如果大家喜欢记得关注和分享哟❤
![file](https://img-blog.csdnimg.cn/2019092616120288.jpeg)